<footer class="footer">
    © 2020 Manager Shop <span class="text-muted d-none d-sm-inline-block float-right">Desenvolvido com <i class="mdi mdi-heart text-danger"></i> por Grudigital</span>
</footer>